@ECHO OFF
IF EXIST "%~dp0gradle\wrapper\gradle-wrapper.jar" (
  java -classpath "%~dp0gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
  EXIT /B %ERRORLEVEL%
)
ECHO Gradle wrapper JAR is not included. Run: flutter create --platforms=android .
EXIT /B 1
