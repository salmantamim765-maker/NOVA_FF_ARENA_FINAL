# Android build (phone-only workflow)

This project now includes the Android host project and a GitHub Actions workflow.

Recommended phone-only flow:
1. Upload the ZIP to a GitHub repository using Chrome.
2. Open the repository's Actions tab.
3. Run **Build Android APK** with **Run workflow**.
4. Download the generated `nova-ff-arena-debug-apk` artifact.
5. Install the APK on the Android phone.

Before any production release, configure a real release keystore/Play App Signing and production Supabase configuration. Never put service-role keys or payment secrets in the repository or APK.
