import 'package:supabase_flutter/supabase_flutter.dart';

class MatchRepository {
  MatchRepository(this.client);
  final SupabaseClient client;

  Future<List<Map<String, dynamic>>> upcomingMatches() async {
    final rows = await client.from('matches').select().eq('status', 'upcoming').order('starts_at');
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<Map<String, dynamic>> claimSlot({required String matchId, required int slot}) async {
    final row = await client.rpc('claim_match_slot', params: {
      'p_match_id': matchId,
      'p_slot_number': slot,
    });
    return Map<String, dynamic>.from(row as Map);
  }

  Future<List<Map<String, dynamic>>> occupiedSlots(String matchId) async {
    final rows = await client.from('match_slots').select('slot_number,user_id').eq('match_id', matchId);
    return List<Map<String, dynamic>>.from(rows);
  }
}
