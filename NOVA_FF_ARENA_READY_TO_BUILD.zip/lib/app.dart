import 'package:flutter/material.dart';

import 'core/theme/app_theme.dart';
import 'screens/auth/login_screen.dart';
import 'screens/home/home_shell.dart';
import 'core/backend/backend.dart';
import 'screens/support/feedback_screen.dart';
import 'screens/wallet/sandbox_deposit_screen.dart';
import 'screens/results/results_screen.dart';
import 'screens/leaderboard/leaderboard_screen.dart';

class NovaFfArenaApp extends StatelessWidget {
  const NovaFfArenaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'NOVA FF ARENA',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark(),
      initialRoute: LoginScreen.routeName,
      routes: {
        LoginScreen.routeName: (_) => const LoginScreen(),
        HomeShell.routeName: (_) => const HomeShell(),
        FeedbackScreen.routeName: (_) => const FeedbackScreen(),
        SandboxDepositScreen.routeName: (_) => const SandboxDepositScreen(),
        '/results': (_) => const ResultsScreen(),
        '/leaderboard': (_) => const LeaderboardScreen(),
      },
    );
  }
}
