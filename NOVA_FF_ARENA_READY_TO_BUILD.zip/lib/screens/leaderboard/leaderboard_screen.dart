import 'package:flutter/material.dart';
import '../../models/leaderboard_entry.dart';

class LeaderboardScreen extends StatelessWidget {
  const LeaderboardScreen({super.key});

  static const entries = <LeaderboardEntry>[
    LeaderboardEntry(playerName: 'NFA_RUSHER', matches: 42, wins: 15, points: 486),
    LeaderboardEntry(playerName: 'ShadowBD', matches: 38, wins: 11, points: 421),
    LeaderboardEntry(playerName: 'NovaX', matches: 51, wins: 9, points: 397),
    LeaderboardEntry(playerName: 'RX_KING', matches: 35, wins: 8, points: 352),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('LEADERBOARD')),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: entries.length,
        separatorBuilder: (_, __) => const SizedBox(height: 10),
        itemBuilder: (_, i) => Card(
          child: ListTile(
            leading: CircleAvatar(child: Text('${i + 1}')),
            title: Text(entries[i].playerName),
            subtitle: Text(
              '${entries[i].matches} matches  •  ${entries[i].wins} wins',
            ),
            trailing: Text(
              '${entries[i].points} pts',
              style: const TextStyle(fontWeight: FontWeight.w800),
            ),
          ),
        ),
      ),
    );
  }
}
