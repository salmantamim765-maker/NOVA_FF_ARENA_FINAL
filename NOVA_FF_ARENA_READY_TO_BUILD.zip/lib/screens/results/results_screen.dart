import 'package:flutter/material.dart';
import '../../models/player_result.dart';

class ResultsScreen extends StatelessWidget {
  const ResultsScreen({super.key});

  static const results = <PlayerResult>[
    PlayerResult(playerName: 'NFA_RUSHER', kills: 8, placement: 1, points: 24),
    PlayerResult(playerName: 'ShadowBD', kills: 6, placement: 2, points: 19),
    PlayerResult(playerName: 'NovaX', kills: 5, placement: 3, points: 16),
    PlayerResult(playerName: 'RX_KING', kills: 3, placement: 4, points: 11),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('MATCH RESULTS')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _header(context),
          const SizedBox(height: 14),
          ...results.asMap().entries.map(
                (entry) => _resultTile(context, entry.key + 1, entry.value),
              ),
        ],
      ),
    );
  }

  Widget _header(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(18),
      ),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('BR SOLO • MATCH #1007',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          SizedBox(height: 6),
          Text('Final scoreboard • demo data'),
        ],
      ),
    );
  }

  Widget _resultTile(BuildContext context, int rank, PlayerResult r) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: ListTile(
        leading: CircleAvatar(child: Text('$rank')),
        title: Text(r.playerName),
        subtitle: Text('${r.kills} kills  •  ${r.points} points'),
        trailing: Text(
          '#${r.placement}',
          style: const TextStyle(fontWeight: FontWeight.w800),
        ),
      ),
    );
  }
}
