import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../models/match.dart';

class MatchDetailsScreen extends StatefulWidget {
  const MatchDetailsScreen({super.key, required this.match, required this.store});
  final TournamentMatch match; final MatchStore store;
  @override State<MatchDetailsScreen> createState()=>_MatchDetailsScreenState();
}
class _MatchDetailsScreenState extends State<MatchDetailsScreen>{
  int? selected;
  @override Widget build(BuildContext context){
    final m=widget.match;
    return Scaffold(appBar:AppBar(title:const Text('Match Details')),body:ListView(padding:const EdgeInsets.all(18),children:[
      Card(child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text(m.title,style:const TextStyle(fontSize:23,fontWeight:FontWeight.w900)),const SizedBox(height:6),Text(m.mode,style:const TextStyle(color:AppColors.neonBlue,fontWeight:FontWeight.w800)),const SizedBox(height:18),
        Row(children:[_Info('PRIZE','৳${m.prize}'),_Info('ENTRY','৳${m.entryFee}'),_Info('SLOTS','${m.availableSlots}/${m.totalSlots}')]),
      ]))),
      const SizedBox(height:14),
      if(m.status==MatchStatus.upcoming) ...[
        const Text('Select your slot',style:TextStyle(fontSize:19,fontWeight:FontWeight.w900)),const SizedBox(height:10),
        GridView.builder(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:4,crossAxisSpacing:8,mainAxisSpacing:8),itemCount:m.totalSlots,itemBuilder:(c,i){final n=i+1;final taken=m.reservedSlots.contains(n);final sel=selected==n;return InkWell(onTap:taken?null:()=>setState(()=>selected=n),child:Container(decoration:BoxDecoration(color:taken?AppColors.surface2:(sel?AppColors.primary:AppColors.surface),borderRadius:BorderRadius.circular(10),border:Border.all(color:sel?AppColors.neonBlue:AppColors.border)),child:Center(child:Text('$n',style:TextStyle(fontWeight:FontWeight.w900,color:taken?AppColors.textSecondary:Colors.white)))));}),
        const SizedBox(height:16),
        SizedBox(height:52,child:ElevatedButton(onPressed:selected==null?null:(){final ok=widget.store.join(m.id,selected!); if(ok) {ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Slot confirmed successfully (demo).'))); Navigator.pop(context);} },child:Text(selected==null?'SELECT A SLOT':'CONFIRM SLOT • #$selected'))),
      ] else Card(child:Padding(padding:const EdgeInsets.all(16),child:Text(m.status==MatchStatus.live?'This match is live. Room details will appear when available.':'This match is completed.'))),
      const SizedBox(height:16),Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Rules',style:TextStyle(fontSize:18,fontWeight:FontWeight.w900)),const SizedBox(height:8),Text(m.rules),const SizedBox(height:12),const Text('Room ID / Password',style:TextStyle(fontWeight:FontWeight.w800)),const SizedBox(height:5),Text(m.roomId==null?'Not released yet':'${m.roomId} / ${m.roomPassword ?? '—'}',style:const TextStyle(color:AppColors.textSecondary))]))),
    ]));
  }
}
class _Info extends StatelessWidget{const _Info(this.a,this.b);final String a,b;@override Widget build(BuildContext c)=>Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(a,style:const TextStyle(fontSize:11,color:AppColors.textSecondary)),const SizedBox(height:4),Text(b,style:const TextStyle(fontWeight:FontWeight.w900))]));}
