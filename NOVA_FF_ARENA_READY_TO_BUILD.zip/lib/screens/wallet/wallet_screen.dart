import 'package:flutter/material.dart';

import '../../core/payments/payment_provider.dart';
import '../../models/wallet_transaction.dart';

class WalletScreen extends StatelessWidget {
  const WalletScreen({super.key});

  static const List<WalletTransaction> transactions = [
    WalletTransaction(
      id: 'NFA-TX-1001',
      type: TransactionType.deposit,
      amount: 500,
      status: TransactionStatus.success,
      provider: 'SANDBOX',
      createdAt: '2026-09-18 08:10',
    ),
    WalletTransaction(
      id: 'NFA-TX-1000',
      type: TransactionType.prize,
      amount: 750,
      status: TransactionStatus.success,
      provider: 'NFA',
      createdAt: '2026-09-17 22:40',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('WALLET')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Card(
            child: Padding(
              padding: EdgeInsets.all(22),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('AVAILABLE BALANCE'),
                  SizedBox(height: 8),
                  Text(
                    '৳1,250',
                    style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: _ActionCard(
                  icon: Icons.add_circle_outline,
                  label: 'Add Money',
                  onTap: () => Navigator.pushNamed(context, '/wallet/sandbox-deposit'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _ActionCard(
                  icon: Icons.account_balance_wallet_outlined,
                  label: 'Withdraw',
                  onTap: _showWithdrawInfo,
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          Text(
            'TRANSACTION HISTORY',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w900,
                ),
          ),
          const SizedBox(height: 10),
          ...transactions.map((tx) => _TransactionTile(tx: tx)),
          const SizedBox(height: 8),
          const Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Text(
                'Wallet balance is ledger-controlled. The client cannot directly '
                'credit, debit, or mark a payment successful. Real provider checkout '
                'remains disabled until the approved backend integration is configured.',
              ),
            ),
          ),
        ],
      ),
    );
  }

  static void _showDepositInfo(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (_) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Add Money',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 10),
              const Text(
                'Sandbox/test mode only. Production flow will use an approved '
                'provider checkout, server-side verification, and an idempotent ledger.',
              ),
              const SizedBox(height: 12),
              ListTile(
                leading: const Icon(Icons.science_outlined),
                title: const Text('Sandbox payment'),
                subtitle: Text(PaymentProviderType.sandbox.name.toUpperCase()),
                onTap: () => Navigator.pop(context),
              ),
              const ListTile(
                leading: Icon(Icons.account_balance_wallet_outlined),
                title: Text('bKash'),
                subtitle: Text('Available after approved backend configuration'),
              ),
              const ListTile(
                leading: Icon(Icons.payments_outlined),
                title: Text('Nagad'),
                subtitle: Text('Available after approved backend configuration'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  static void _showWithdrawInfo(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (_) => const Padding(
        padding: EdgeInsets.fromLTRB(20, 8, 20, 28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Withdraw',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
            ),
            SizedBox(height: 10),
            Text(
              'Withdrawals remain server-controlled. The backend must check identity, '
              'available ledger balance, limits, idempotency, and provider verification '
              'before changing wallet state.',
            ),
          ],
        ),
      ),
    );
  }
}

class _ActionCard extends StatelessWidget {
  const _ActionCard({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 18),
          child: Column(
            children: [
              Icon(icon),
              const SizedBox(height: 7),
              Text(label),
            ],
          ),
        ),
      ),
    );
  }
}

class _TransactionTile extends StatelessWidget {
  const _TransactionTile({required this.tx});

  final WalletTransaction tx;

  @override
  Widget build(BuildContext context) {
    final sign = tx.type == TransactionType.withdrawal ? '-' : '+';
    return Card(
      margin: const EdgeInsets.only(bottom: 9),
      child: ListTile(
        leading: Icon(
          tx.type == TransactionType.withdrawal
              ? Icons.arrow_upward
              : Icons.arrow_downward,
        ),
        title: Text('$sign৳${tx.amount} • ${tx.provider}'),
        subtitle: Text('${tx.id} • ${tx.createdAt}'),
        trailing: Text(
          tx.status.name.toUpperCase(),
          style: const TextStyle(fontWeight: FontWeight.w800),
        ),
      ),
    );
  }
}
