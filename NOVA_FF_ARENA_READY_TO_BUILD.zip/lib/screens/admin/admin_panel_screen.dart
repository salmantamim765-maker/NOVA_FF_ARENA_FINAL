import 'package:flutter/material.dart';
import '../../models/admin_match.dart';

class AdminPanelScreen extends StatefulWidget {
  const AdminPanelScreen({super.key});

  @override
  State<AdminPanelScreen> createState() => _AdminPanelScreenState();
}

class _AdminPanelScreenState extends State<AdminPanelScreen> {
  final List<AdminMatch> _matches = [
    const AdminMatch(
      id: 'NFA-1007',
      title: 'BR Solo Night Cup',
      mode: 'BR Solo',
      entryFee: 30,
      prizePool: 1500,
      totalSlots: 48,
      bookedSlots: 31,
      status: AdminMatchStatus.published,
    ),
    const AdminMatch(
      id: 'NFA-1008',
      title: 'CS 4v4 Clash',
      mode: 'CS 4v4',
      entryFee: 50,
      prizePool: 3000,
      totalSlots: 32,
      bookedSlots: 32,
      status: AdminMatchStatus.live,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ADMIN PANEL')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _overview(context),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'MATCH MANAGEMENT',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w900,
                    ),
              ),
              FilledButton.icon(
                onPressed: _showCreateMatchDialog,
                icon: const Icon(Icons.add),
                label: const Text('Create'),
              ),
            ],
          ),
          const SizedBox(height: 10),
          ..._matches.map(_matchCard),
          const SizedBox(height: 12),
          const Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Text(
                'Demo admin panel only. Production admin actions must be protected '
                'by server-side roles, RLS, audit logs, and backend authorization.',
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _overview(BuildContext context) {
    final published = _matches
        .where((m) => m.status == AdminMatchStatus.published)
        .length;
    final live =
        _matches.where((m) => m.status == AdminMatchStatus.live).length;
    final booked = _matches.fold<int>(0, (sum, m) => sum + m.bookedSlots);

    return Row(
      children: [
        Expanded(child: _stat(context, 'Matches', '${_matches.length}')),
        const SizedBox(width: 8),
        Expanded(child: _stat(context, 'Published', '$published')),
        const SizedBox(width: 8),
        Expanded(child: _stat(context, 'Live', '$live')),
        const SizedBox(width: 8),
        Expanded(child: _stat(context, 'Booked', '$booked')),
      ],
    );
  }

  Widget _stat(BuildContext context, String label, String value) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 6),
        child: Column(
          children: [
            Text(value,
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.w900,
                    )),
            const SizedBox(height: 4),
            Text(label, textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }

  Widget _matchCard(AdminMatch match) {
    final remaining = match.totalSlots - match.bookedSlots;
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(match.title,
                style: const TextStyle(fontWeight: FontWeight.w900)),
            const SizedBox(height: 5),
            Text(
              '${match.id} • ${match.mode} • ৳${match.entryFee} entry • '
              '৳${match.prizePool} prize',
            ),
            const SizedBox(height: 5),
            Text('Slots: ${match.bookedSlots}/${match.totalSlots} '
                '($remaining remaining)'),
            const SizedBox(height: 8),
            Row(
              children: [
                Chip(label: Text(match.status.name.toUpperCase())),
                const Spacer(),
                TextButton(
                  onPressed: () => _showStatusDialog(match),
                  child: const Text('Status'),
                ),
                TextButton(
                  onPressed: () => _showEditDialog(match),
                  child: const Text('Edit'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _showCreateMatchDialog() async {
    final title = TextEditingController();
    final mode = TextEditingController(text: 'BR Solo');
    final entry = TextEditingController(text: '30');
    final prize = TextEditingController(text: '1500');
    final slots = TextEditingController(text: '48');

    await showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Create Demo Match'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: title, decoration: const InputDecoration(labelText: 'Title')),
              TextField(controller: mode, decoration: const InputDecoration(labelText: 'Mode')),
              TextField(controller: entry, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Entry fee')),
              TextField(controller: prize, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Prize pool')),
              TextField(controller: slots, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Total slots')),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(
            onPressed: () {
              final parsedEntry = int.tryParse(entry.text);
              final parsedPrize = int.tryParse(prize.text);
              final parsedSlots = int.tryParse(slots.text);
              if (title.text.trim().isEmpty ||
                  parsedEntry == null ||
                  parsedPrize == null ||
                  parsedSlots == null ||
                  parsedEntry < 0 ||
                  parsedPrize < 0 ||
                  parsedSlots <= 0) {
                return;
              }
              setState(() {
                _matches.add(AdminMatch(
                  id: 'NFA-${1000 + _matches.length + 1}',
                  title: title.text.trim(),
                  mode: mode.text.trim().isEmpty ? 'BR Solo' : mode.text.trim(),
                  entryFee: parsedEntry,
                  prizePool: parsedPrize,
                  totalSlots: parsedSlots,
                  bookedSlots: 0,
                  status: AdminMatchStatus.draft,
                ));
              });
              Navigator.pop(context);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  Future<void> _showEditDialog(AdminMatch match) async {
    final title = TextEditingController(text: match.title);
    await showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Edit Match'),
        content: TextField(
          controller: title,
          decoration: const InputDecoration(labelText: 'Match title'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(
            onPressed: () {
              if (title.text.trim().isEmpty) return;
              setState(() {
                final index = _matches.indexOf(match);
                _matches[index] = match.copyWith(title: title.text.trim());
              });
              Navigator.pop(context);
            },
            child: const Text('Update'),
          ),
        ],
      ),
    );
  }

  Future<void> _showStatusDialog(AdminMatch match) async {
    final selected = await showDialog<AdminMatchStatus>(
      context: context,
      builder: (_) => SimpleDialog(
        title: const Text('Change status'),
        children: AdminMatchStatus.values
            .map(
              (status) => SimpleDialogOption(
                onPressed: () => Navigator.pop(context, status),
                child: Text(status.name.toUpperCase()),
              ),
            )
            .toList(),
      ),
    );
    if (!mounted || selected == null) return;
    setState(() {
      final index = _matches.indexOf(match);
      _matches[index] = match.copyWith(status: selected);
    });
  }
}
