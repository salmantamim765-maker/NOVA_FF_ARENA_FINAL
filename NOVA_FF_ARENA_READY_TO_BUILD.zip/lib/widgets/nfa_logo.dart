import 'package:flutter/material.dart';

import '../core/theme/app_colors.dart';

class NfaLogo extends StatelessWidget {
  const NfaLogo({
    super.key,
    this.compact = false,
  });

  final bool compact;

  @override
  Widget build(BuildContext context) {
    final size = compact ? 42.0 : 76.0;

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(compact ? 12 : 20),
            gradient: const LinearGradient(
              colors: [AppColors.primary, AppColors.neonBlue],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            boxShadow: const [
              BoxShadow(
                color: Color(0x553157FF),
                blurRadius: 20,
                spreadRadius: 1,
              ),
            ],
          ),
          child: Center(
            child: Text(
              'NFA',
              style: TextStyle(
                color: Colors.white,
                fontSize: compact ? 13 : 21,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.2,
              ),
            ),
          ),
        ),
        if (!compact) ...[
          const SizedBox(height: 12),
          const Text(
            'NOVA FF ARENA',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.1,
            ),
          ),
          const SizedBox(height: 3),
          const Text(
            'PLAY • COMPETE • CONQUER',
            style: TextStyle(
              color: AppColors.textSecondary,
              fontSize: 10,
              fontWeight: FontWeight.w700,
              letterSpacing: 1.6,
            ),
          ),
        ],
      ],
    );
  }
}
