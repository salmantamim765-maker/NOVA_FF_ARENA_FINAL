import 'package:flutter/material.dart';

import '../core/theme/app_colors.dart';

class NfaGradientCard extends StatelessWidget {
  const NfaGradientCard({super.key, required this.child, this.padding = const EdgeInsets.all(18)});
  final Widget child;
  final EdgeInsetsGeometry padding;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [AppColors.primaryDeep, AppColors.primary, Color(0xFF3B5FFF)],
        ),
        boxShadow: const [
          BoxShadow(color: Color(0x332E52FF), blurRadius: 28, offset: Offset(0, 12)),
        ],
      ),
      child: child,
    );
  }
}

class NfaSectionTitle extends StatelessWidget {
  const NfaSectionTitle({super.key, required this.title, this.action});
  final String title;
  final Widget? action;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(child: Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900))),
        if (action != null) action!,
      ],
    );
  }
}

class NfaGlowIcon extends StatelessWidget {
  const NfaGlowIcon({super.key, required this.icon, this.size = 48});
  final IconData icon;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: AppColors.primary.withValues(alpha: .14),
        borderRadius: BorderRadius.circular(size * .30),
        border: Border.all(color: AppColors.borderGlow.withValues(alpha: .55)),
        boxShadow: const [BoxShadow(color: Color(0x142E52FF), blurRadius: 18)],
      ),
      child: Icon(icon, color: AppColors.neonBlue, size: size * .48),
    );
  }
}
