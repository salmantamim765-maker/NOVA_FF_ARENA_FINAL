import 'package:supabase_flutter/supabase_flutter.dart';

import 'supabase_config.dart';

class Backend {
  static Future<void> initialize() async {
    if (!SupabaseConfig.isConfigured) return;
    await Supabase.initialize(
      url: SupabaseConfig.url,
      anonKey: SupabaseConfig.anonKey,
    );
  }

  static bool get isConfigured =>
      SupabaseConfig.isConfigured && Supabase.instance.isInitialized;

  static SupabaseClient get client {
    if (!isConfigured) {
      throw StateError(
        'Supabase is not configured. Provide SUPABASE_URL and SUPABASE_ANON_KEY.',
      );
    }
    return Supabase.instance.client;
  }
}
