enum PaymentProviderType { bkash, nagad, sandbox }

class PaymentRequest {
  final int amount;
  final String idempotencyKey;

  const PaymentRequest({
    required this.amount,
    required this.idempotencyKey,
  });
}

class PaymentSession {
  final String checkoutUrl;
  final String providerReference;

  const PaymentSession({
    required this.checkoutUrl,
    required this.providerReference,
  });
}

class PaymentStatus {
  final String transactionId;
  final PaymentTransactionState state;
  final int amount;
  final String? providerReference;

  const PaymentStatus({
    required this.transactionId,
    required this.state,
    required this.amount,
    this.providerReference,
  });
}

enum PaymentTransactionState {
  pending,
  success,
  failed,
  cancelled,
  expired,
}

abstract interface class PaymentProvider {
  PaymentProviderType get type;

  Future<PaymentSession> createPayment(PaymentRequest request);

  Future<PaymentStatus> verifyPayment(String transactionId);

  Future<PaymentStatus> getPaymentStatus(String transactionId);

  Future<void> refundPayment({
    required String transactionId,
    required String reason,
  });
}
