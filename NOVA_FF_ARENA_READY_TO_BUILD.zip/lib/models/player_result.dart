class PlayerResult {
  final String playerName;
  final int kills;
  final int placement;
  final int points;

  const PlayerResult({
    required this.playerName,
    required this.kills,
    required this.placement,
    required this.points,
  });
}
