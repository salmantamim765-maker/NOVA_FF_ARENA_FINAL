class LeaderboardEntry {
  final String playerName;
  final int matches;
  final int wins;
  final int points;

  const LeaderboardEntry({
    required this.playerName,
    required this.matches,
    required this.wins,
    required this.points,
  });
}
