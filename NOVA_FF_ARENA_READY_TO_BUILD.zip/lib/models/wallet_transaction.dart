enum TransactionType { deposit, withdrawal, prize }

enum TransactionStatus { pending, success, failed }

class WalletTransaction {
  final String id;
  final TransactionType type;
  final int amount;
  final TransactionStatus status;
  final String provider;
  final String createdAt;

  const WalletTransaction({
    required this.id,
    required this.type,
    required this.amount,
    required this.status,
    required this.provider,
    required this.createdAt,
  });
}
