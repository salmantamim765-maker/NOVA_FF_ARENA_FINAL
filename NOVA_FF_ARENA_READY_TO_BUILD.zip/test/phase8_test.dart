import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:nova_ff_arena/screens/support/feedback_screen.dart';

void main() {
  testWidgets('feedback screen renders required controls', (tester) async {
    await tester.pumpWidget(const MaterialApp(home: FeedbackScreen()));

    expect(find.text('FEEDBACK'), findsOneWidget);
    expect(find.text('We value your feedback'), findsOneWidget);
    expect(find.text('SEND FEEDBACK'), findsOneWidget);
  });

  testWidgets('empty feedback is blocked by validation', (tester) async {
    await tester.pumpWidget(const MaterialApp(home: FeedbackScreen()));
    await tester.tap(find.text('SEND FEEDBACK'));
    await tester.pump();

    expect(find.text('Please write at least a few words'), findsOneWidget);
  });
}
