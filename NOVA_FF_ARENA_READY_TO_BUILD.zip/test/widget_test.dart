import 'package:flutter_test/flutter_test.dart';

import 'package:nova_ff_arena/app.dart';

void main() {
  testWidgets('NOVA FF ARENA opens on login screen', (tester) async {
    await tester.pumpWidget(const NovaFfArenaApp());

    expect(find.text('Welcome back'), findsOneWidget);
    expect(find.text('LOGIN'), findsOneWidget);
    expect(find.text('CREATE ACCOUNT'), findsOneWidget);
  });
}
