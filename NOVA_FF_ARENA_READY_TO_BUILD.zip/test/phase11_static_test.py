from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


colors = read("lib/core/theme/app_colors.dart")
theme = read("lib/core/theme/app_theme.dart")
home = read("lib/screens/home/home_shell.dart")
app = read("lib/app.dart")

assert "0XFF050509" in colors.upper()
assert "0XFF2447FF" in colors.upper()
assert "0XFF4D72FF" in colors.upper()
assert "NfaGradientCard" in home
assert "NfaGlowIcon" in home
assert "FeedbackScreen.routeName" in home
assert "FeedbackScreen.routeName" in app
assert "withValues(alpha: .22)" in theme
assert "NavigationBarThemeData" in theme
assert "cardTheme" in theme

# Guard against the old bad route literal and const ListTile/onTap pattern.
assert "'/support/bug-report'" not in home
assert "const ListTile(leading: const" not in home

print("PHASE 11 STATIC CHECKS: PASS")
