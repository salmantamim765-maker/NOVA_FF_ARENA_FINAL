from pathlib import Path

root = Path(__file__).resolve().parents[1]
schema = (root / 'supabase/phase9_schema.sql').read_text()
create_fn = (root / 'supabase/functions/create-payment-intent/index.ts').read_text()
status_fn = (root / 'supabase/functions/payment-status/index.ts').read_text()

assert 'security definer' in schema.lower()
assert 'unique(user_id, idempotency_key)' in schema
assert 'provider_reference' in schema
assert 'wallet' in schema.lower()
assert 'wallet balance' in schema.lower()
assert 'SUPABASE_SERVICE_ROLE_KEY' not in create_fn
assert 'SUPABASE_SERVICE_ROLE_KEY' not in status_fn
assert 'client' not in create_fn.lower() or 'supabase' in create_fn.lower()
assert 'auth.getUser' in create_fn
assert 'auth.getUser' in status_fn
assert 'eq(\'user_id\', userData.user.id)' in status_fn
print('Phase 9 static security/contract checks: PASS')
