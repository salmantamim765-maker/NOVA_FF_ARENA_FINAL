# NOVA FF ARENA — Phase 3

Phase 3 adds the production-oriented backend foundation for authentication and database-backed match/slot operations.

## Included
- Supabase Flutter client integration (configuration via `--dart-define`)
- Email/password and phone/password auth repository
- Password reset repository method
- PostgreSQL schema for profiles, matches and match slots
- Row Level Security policies
- Atomic server-side slot claim RPC with concurrency protection
- Match repository for database reads and slot claims
- Demo UI remains usable when Supabase is not configured

## Setup
1. Create a Supabase project.
2. Run `supabase/schema.sql` in the Supabase SQL editor.
3. Enable the authentication providers you intend to use.
4. Run the app with the project URL and **anon/publishable key only**:

```bash
flutter pub get
flutter run --dart-define=SUPABASE_URL=https://YOUR_PROJECT.supabase.co --dart-define=SUPABASE_ANON_KEY=YOUR_ANON_KEY
```

Never put a Supabase service-role key in Flutter/mobile code.

## Security notes
- Wallet/payment is intentionally NOT implemented in Phase 3.
- Slot uniqueness is enforced in PostgreSQL, not just the client.
- Client-side balance mutation and payment verification are not present.
- Production deployment still needs email/phone verification policy, admin authorization, monitoring, backups, rate limiting and provider/legal review.

## Verification status
Static checks were performed on the generated files and SQL. Flutter SDK is unavailable in the build environment, so `flutter analyze` and `flutter test` could not be executed here.

## Phase 4 — Results + Leaderboard + Profile
Added:
- Match Results screen with placement, kills and points.
- Leaderboard screen with matches, wins and points.
- Profile stats screen.
- Navigation routes for Results and Leaderboard.
- Demo/local data only; real user statistics should be loaded from Supabase in the next integration step.

Validation:
- Static structure and source checks completed.
- Flutter SDK is not available in this environment, so `flutter analyze` and `flutter test` could not be executed here.

## Phase 5 — Secure Wallet + Transaction System
Added:
- Wallet UI with balance, add-money and withdrawal entry points.
- Transaction history model and demo history.
- Secure wallet ledger SQL foundation.
- User-only transaction SELECT RLS policy.
- Client-side wallet mutation intentionally omitted.
- Production payment flow documented for approved bKash/Nagad checkout and server verification.

Security:
- No bKash/Nagad credentials, PINs, OTPs, service-role keys, or secrets are stored in the app.
- Real balance changes must happen only in trusted backend code after provider verification.
- Real-money tournament/payment features require provider approval and applicable legal/compliance review.

Validation:
- Static source/security checks completed.
- Flutter SDK is not available in this environment, so `flutter analyze` and `flutter test` could not be executed here.

## Phase 6 — Admin Panel
Added:
- Demo admin dashboard with match statistics.
- Create match form.
- Edit match title.
- Match status management.
- Slot occupancy overview.
- Admin role SQL foundation with server-side `is_admin()` function.
- Production security notes for roles, RLS, and audit logs.

Important:
- The admin UI is local/demo and is not a production authorization system.
- Real admin permissions must be enforced in Supabase policies/backend code.
- Flutter SDK is unavailable in this environment, so `flutter analyze` and `flutter test` were not run.

## Phase 7 — Payment Architecture + Security Hardening
Added:
- Provider abstraction for bKash and Nagad.
- Wallet provider chooser UI.
- Backend integration contract for checkout, callbacks/webhooks, verification and idempotency.
- Secret-management documentation.
- Explicit pending/success/failed/cancelled/timeout handling requirements.
- No provider credentials or direct payment API calls in the Flutter client.

Important:
- Real payment is NOT enabled by this phase.
- Production activation requires an approved merchant/provider setup, trusted backend,
  server-side verification, and applicable legal/compliance review.
- Provider documentation/terms can change; use current official onboarding materials.

Validation:
- Static source/security checks completed.
- Flutter SDK is not available in this environment, so `flutter analyze` and `flutter test` could not be executed here.


## Phase 8 — Production payment readiness + Feedback
Added:
- Expanded `PaymentProvider` contract for create, verify, status and refund.
- Explicit non-money-moving `SandboxPaymentProvider` for integration/UI testing.
- bKash/Nagad client adapters remain credential-free and backend-only.
- Payment idempotency and provider-reference uniqueness migration.
- New in-app `Feedback` screen for ideas, suggestions, and app feedback.
- User-friendly submission/error states.
- Feedback entry point from the Home/Profile tab.
- Updated wallet demo screen to remove duplicate implementation and clarify ledger control.

Important:
- Production provider endpoints/credentials are intentionally not invented.
- Real bKash/Nagad activation requires the officially approved merchant/gateway configuration,
  current provider documentation, trusted server-side verification, and applicable compliance review.
- The sandbox provider does not move money and must not be used to credit the real wallet.

Validation:
- Static source/schema checks completed.
- Flutter SDK is not available in this environment, so `flutter analyze` and `flutter test` could not be executed.

## Phase 9 — Trusted backend payment-intent foundation
Added:
- `payment_intents` server-side state table with per-user idempotency protection.
- Authenticated `create_payment_intent` SECURITY DEFINER RPC with amount/provider validation.
- Audit log foundation for payment-intent creation.
- Authenticated Edge Function boundary for creating intents.
- Authenticated Edge Function boundary for reading server-stored payment status.
- Provider checkout/verification deliberately left unimplemented until approved provider documentation and credentials are supplied.
- No client-controlled success flag can credit the wallet.

Validation:
- Static security/contract checks executed with Python and passed.
- Flutter SDK is not available in this environment, so `flutter analyze` and `flutter test` were not executed.
- Supabase migrations/functions were statically reviewed but not deployed to a live Supabase project, so live database/RLS behavior remains to be verified after deployment.
