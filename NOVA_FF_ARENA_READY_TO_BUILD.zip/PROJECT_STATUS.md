# NOVA FF ARENA project status

- Flutter source: included
- Android module: included
- Application ID: `com.novaffarena.nfa`
- Minimum Android SDK: 23
- Supabase schema/functions: included
- Sandbox payment flow: included
- Feedback flow: included
- GitHub Actions APK workflow: included
- Production payment credentials: intentionally not included

Important: this environment does not have the Flutter/Dart SDK, so a real `flutter analyze`, `flutter test`, emulator run, or APK compilation was not performed here. The GitHub Actions workflow performs those checks during an actual build.
