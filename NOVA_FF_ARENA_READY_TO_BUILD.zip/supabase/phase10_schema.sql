
-- NOVA FF ARENA Phase 10
-- Admin bug-report workflow + payment-intent hardening.
-- Apply after phase8/phase9 migrations.

-- Restrict admin role model to the application's three roles.
-- Existing deployments should reconcile legacy admin_roles data before changing it.
alter table if exists public.admin_roles
  drop constraint if exists admin_roles_role_check;

update public.admin_roles
set role = case lower(role)
  when 'admin' then 'ADMIN'
  when 'super_admin' then 'SUPER_ADMIN'
  when 'moderator' then 'ADMIN'
  when 'user' then 'USER'
  else 'USER'
end
where role is not null;

alter table if exists public.admin_roles
  add constraint admin_roles_role_check
  check (role in ('USER', 'ADMIN', 'SUPER_ADMIN'));

create or replace function public.current_app_role()
returns text
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(
    (select upper(role) from public.admin_roles where user_id = auth.uid()),
    'USER'
  );
$$;

revoke all on function public.current_app_role() from public;
grant execute on function public.current_app_role() to authenticated;

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select public.current_app_role() in ('ADMIN', 'SUPER_ADMIN');
$$;

revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to authenticated;

-- Admin-only bug report read/update boundary. No client role is trusted.
create or replace function public.admin_list_bug_reports()
returns setof public.bug_reports
language sql
stable
security definer
set search_path = public
as $$
  select b.*
  from public.bug_reports b
  where public.is_admin()
  order by b.created_at desc
  limit 200;
$$;

revoke all on function public.admin_list_bug_reports() from public;
grant execute on function public.admin_list_bug_reports() to authenticated;

create or replace function public.admin_update_bug_report_status(
  p_id uuid,
  p_status text
)
returns public.bug_reports
language plpgsql
security definer
set search_path = public
as $$
declare
  updated_report public.bug_reports;
begin
  if not public.is_admin() then
    raise exception using errcode = '42501', message = 'ADMIN_REQUIRED';
  end if;

  if p_status not in ('open', 'in_progress', 'resolved', 'closed') then
    raise exception using errcode = '22023', message = 'INVALID_STATUS';
  end if;

  update public.bug_reports
  set status = p_status::public.bug_report_status,
      updated_at = now()
  where id = p_id
  returning * into updated_report;

  if not found then
    raise exception using errcode = 'P0002', message = 'BUG_REPORT_NOT_FOUND';
  end if;

  insert into public.audit_logs(
    actor_user_id, action, entity_type, entity_id, metadata
  )
  values (
    auth.uid(), 'bug_report_status_updated', 'bug_report', p_id::text,
    jsonb_build_object('status', p_status)
  );

  return updated_report;
end;
$$;

revoke all on function public.admin_update_bug_report_status(uuid, text) from public;
grant execute on function public.admin_update_bug_report_status(uuid, text) to authenticated;

-- Keep direct bug-report UPDATE disabled for users.
revoke update, delete on public.bug_reports from authenticated;

-- Payment intents: users may read their own rows only.
revoke insert, update, delete on public.payment_intents from authenticated;

-- Direct client INSERT/UPDATE/DELETE remains revoked. Server-side verification
-- should be the only privileged mutation path; do not add client write policies.

-- IMPORTANT: service-role/server verification can still mutate payment intents,
-- but it must verify the provider response and ledger transaction atomically.
