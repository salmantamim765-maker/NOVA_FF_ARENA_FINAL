-- NOVA FF ARENA Phase 5
-- Secure wallet ledger foundation.
-- Run only after reviewing your Supabase project and legal/provider requirements.

create type public.transaction_type as enum ('deposit', 'withdrawal', 'prize');
create type public.transaction_status as enum ('pending', 'success', 'failed');

create table if not exists public.wallet_transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  amount bigint not null check (amount > 0),
  transaction_type public.transaction_type not null,
  status public.transaction_status not null default 'pending',
  provider text,
  provider_reference text,
  created_at timestamptz not null default now(),
  verified_at timestamptz
);

create index if not exists wallet_transactions_user_created_idx
  on public.wallet_transactions(user_id, created_at desc);

alter table public.wallet_transactions enable row level security;

drop policy if exists "Users read own wallet transactions"
  on public.wallet_transactions;

create policy "Users read own wallet transactions"
on public.wallet_transactions
for select
to authenticated
using (auth.uid() = user_id);

-- IMPORTANT:
-- Do not add an INSERT/UPDATE policy for the client.
-- Deposits, withdrawals, and prize credits should be created/updated
-- by trusted server-side code after authorization and verification.
--
-- Provider API credentials and service-role keys must never be shipped
-- inside the Flutter application.
