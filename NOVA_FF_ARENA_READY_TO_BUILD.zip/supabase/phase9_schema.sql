-- NOVA FF ARENA Phase 9
-- Trusted backend payment-intent foundation + audit logging.
-- Provider API calls are intentionally NOT implemented here because provider
-- endpoints/credentials must come from the approved merchant documentation.

create type public.payment_intent_status as enum ('pending', 'success', 'failed', 'cancelled', 'expired');

create table if not exists public.payment_intents (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  provider text not null check (provider in ('bkash', 'nagad', 'sandbox')),
  amount bigint not null check (amount > 0 and amount <= 100000000),
  idempotency_key text not null,
  provider_reference text,
  status public.payment_intent_status not null default 'pending',
  checkout_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  verified_at timestamptz,
  expires_at timestamptz,
  unique(user_id, idempotency_key)
);

create index if not exists payment_intents_user_created_idx
  on public.payment_intents(user_id, created_at desc);

create unique index if not exists payment_intents_provider_reference_uq
  on public.payment_intents(provider_reference)
  where provider_reference is not null;

alter table public.payment_intents enable row level security;

drop policy if exists "Users read own payment intents" on public.payment_intents;
create policy "Users read own payment intents"
on public.payment_intents for select to authenticated
using (auth.uid() = user_id);

-- No client INSERT/UPDATE/DELETE policies. Creation/mutation goes through
-- this SECURITY DEFINER function and trusted server-side verification.

create table if not exists public.audit_logs (
  id bigint generated always as identity primary key,
  actor_user_id uuid references auth.users(id) on delete set null,
  action text not null check (char_length(trim(action)) between 2 and 100),
  entity_type text not null check (char_length(trim(entity_type)) between 2 and 50),
  entity_id text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists audit_logs_created_idx on public.audit_logs(created_at desc);
create index if not exists audit_logs_actor_idx on public.audit_logs(actor_user_id, created_at desc);
alter table public.audit_logs enable row level security;

-- Users have no direct access to audit logs. Admin reporting should use a
-- server-authorized function/policy after role validation.

create or replace function public.create_payment_intent(
  p_provider text,
  p_amount bigint,
  p_idempotency_key text
)
returns public.payment_intents
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid := auth.uid();
  v_intent public.payment_intents;
begin
  if v_user is null then
    raise exception using errcode = '42501', message = 'Authentication required';
  end if;

  if p_provider not in ('bkash', 'nagad', 'sandbox') then
    raise exception using errcode = '22023', message = 'Unsupported payment provider';
  end if;

  if p_amount is null or p_amount <= 0 or p_amount > 100000000 then
    raise exception using errcode = '22023', message = 'Invalid payment amount';
  end if;

  if p_idempotency_key is null or char_length(trim(p_idempotency_key)) < 16
     or char_length(trim(p_idempotency_key)) > 128 then
    raise exception using errcode = '22023', message = 'Invalid idempotency key';
  end if;

  -- Repeated requests return the same intent instead of creating another one.
  select * into v_intent
  from public.payment_intents
  where user_id = v_user and idempotency_key = trim(p_idempotency_key)
  limit 1;

  if found then
    return v_intent;
  end if;

  insert into public.payment_intents(user_id, provider, amount, idempotency_key)
  values (v_user, p_provider, p_amount, trim(p_idempotency_key))
  returning * into v_intent;

  insert into public.audit_logs(actor_user_id, action, entity_type, entity_id, metadata)
  values (v_user, 'payment_intent_created', 'payment_intent', v_intent.id::text,
          jsonb_build_object('provider', p_provider, 'amount', p_amount));

  return v_intent;
exception
  when unique_violation then
    select * into v_intent
    from public.payment_intents
    where user_id = v_user and idempotency_key = trim(p_idempotency_key)
    limit 1;
    if found then return v_intent; end if;
    raise;
end;
$$;

revoke all on function public.create_payment_intent(text, bigint, text) from public;
grant execute on function public.create_payment_intent(text, bigint, text) to authenticated;

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists payment_intents_updated_at on public.payment_intents;
create trigger payment_intents_updated_at
before update on public.payment_intents
for each row execute function public.set_updated_at();

-- IMPORTANT: This migration only creates a pending intent. It does NOT credit
-- wallet balance. A trusted Edge Function must call the approved provider,
-- validate callbacks/status, and perform the ledger mutation transactionally.
