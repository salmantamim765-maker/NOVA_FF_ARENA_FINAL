import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:nova_ff_arena/screens/support/bug_report_screen.dart';

void main() {
  testWidgets('bug report screen renders required controls', (tester) async {
    await tester.pumpWidget(
      const MaterialApp(home: BugReportScreen()),
    );

    expect(find.text('REPORT A BUG'), findsOneWidget);
    expect(find.text('Bug title'), findsOneWidget);
    expect(find.text('Severity'), findsOneWidget);
    expect(find.text('What went wrong?'), findsOneWidget);
    expect(find.text('SUBMIT REPORT'), findsOneWidget);
  });

  testWidgets('empty bug report is blocked by validation', (tester) async {
    await tester.pumpWidget(
      const MaterialApp(home: BugReportScreen()),
    );

    await tester.tap(find.text('SUBMIT REPORT'));
    await tester.pump();

    expect(find.text('Enter a short bug title'), findsOneWidget);
    expect(find.text('Please provide more detail'), findsOneWidget);
  });

  testWidgets('short description is rejected', (tester) async {
    await tester.pumpWidget(
      const MaterialApp(home: BugReportScreen()),
    );

    await tester.enterText(find.byType(TextFormField).at(0), 'Slot bug');
    await tester.enterText(find.byType(TextFormField).at(1), 'Too short');
    await tester.tap(find.text('SUBMIT REPORT'));
    await tester.pump();

    expect(find.text('Please provide more detail'), findsOneWidget);
  });

  testWidgets('severity selector defaults to medium', (tester) async {
    await tester.pumpWidget(
      const MaterialApp(home: BugReportScreen()),
    );

    expect(find.text('medium'), findsOneWidget);
  });

  testWidgets('bug report screen remains usable after validation failure', (tester) async {
    await tester.pumpWidget(
      const MaterialApp(home: BugReportScreen()),
    );

    await tester.tap(find.text('SUBMIT REPORT'));
    await tester.pump();

    expect(find.text('REPORT A BUG'), findsOneWidget);
    expect(find.text('SUBMIT REPORT'), findsOneWidget);
  });
}
