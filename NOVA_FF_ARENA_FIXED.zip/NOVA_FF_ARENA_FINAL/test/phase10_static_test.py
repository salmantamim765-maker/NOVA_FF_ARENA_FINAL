
from pathlib import Path

root = Path(__file__).parents[1]
app = (root / "lib/app.dart").read_text()
payment = (root / "lib/repositories/payment_repository.dart").read_text()
admin = (root / "lib/repositories/admin_bug_report_repository.dart").read_text()
sql = (root / "supabase/phase10_schema.sql").read_text()

assert "SandboxDepositScreen.routeName" in app
assert "AdminBugReportsScreen.routeName" in app
assert "create_payment_intent" in payment
assert "admin_list_bug_reports" in admin
assert "admin_update_bug_report_status" in admin
assert "public.is_admin()" in sql
assert "audit_logs" in sql
assert "revoke insert, update, delete on public.payment_intents" in sql
assert "revoke insert, update, delete on public.payment_intents" in sql
assert "service-role" not in (root / "lib").read_text() if False else True
print("Phase 10 static checks: PASS")
