# NOVA FF ARENA — Phone-only APK build

This repository is the Flutter source project. A ZIP is **not** directly installable on Android.

## Build an APK using only an Android phone

1. Create a GitHub repository.
2. Upload the contents of this folder (not the outer folder itself).
3. Open **Actions** → **Build Android APK** → **Run workflow**.
4. Wait for `flutter analyze`, `flutter test`, and the APK build to finish.
5. Open the completed workflow run → **Artifacts** → `nova-ff-arena-debug-apk`.
6. Download the APK to the phone and install it.

The workflow regenerates any missing Flutter-generated Android wrapper files before building, so the source archive does not need to contain a large Gradle wrapper JAR.

## Supabase

For a connected backend build, add GitHub Actions secrets named:
- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`

Never put a Supabase service-role/private key in Flutter source or GitHub Actions build arguments.

## Current payment state

The project contains a provider abstraction and sandbox flow. Production bKash credentials/configuration must be supplied through an officially approved merchant/gateway setup and verified server-side before production use.
