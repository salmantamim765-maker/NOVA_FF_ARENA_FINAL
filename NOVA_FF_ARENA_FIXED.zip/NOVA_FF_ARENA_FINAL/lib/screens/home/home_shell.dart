import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../models/match.dart';
import '../../widgets/nfa_logo.dart';
import '../../widgets/premium_ui.dart';
import '../matches/match_details_screen.dart';
import '../support/bug_report_screen.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  static const routeName = '/home';

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;
  final MatchStore _matchStore = MatchStore();
  static const _titles = ['Home', 'Matches', 'Leaderboard', 'Profile'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            const NfaLogo(compact: true),
            const SizedBox(width: 11),
            Text(_titles[_index]),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Notifications',
            onPressed: () {},
            icon: const Icon(Icons.notifications_none_rounded),
          ),
          const SizedBox(width: 4),
        ],
      ),
      body: IndexedStack(
        index: _index,
        children: [
          _HomeTab(store: _matchStore),
          _MatchesTab(store: _matchStore),
          const _LeaderboardTab(),
          const _ProfileTab(),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (value) => setState(() => _index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.sports_esports_outlined), selectedIcon: Icon(Icons.sports_esports), label: 'Matches'),
          NavigationDestination(icon: Icon(Icons.emoji_events_outlined), selectedIcon: Icon(Icons.emoji_events), label: 'Ranks'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

class _HomeTab extends StatelessWidget {
  const _HomeTab({required this.store});
  final MatchStore store;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) => ListView(
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 32),
        children: [
          const _WelcomeCard(),
          const SizedBox(height: 24),
          const NfaSectionTitle(title: 'Game modes'),
          const SizedBox(height: 12),
          const Row(children: [Expanded(child: _ModeCard('BR SOLO', Icons.person_outline)), SizedBox(width: 10), Expanded(child: _ModeCard('BR DUO', Icons.people_outline))]),
          const SizedBox(height: 10),
          const Row(children: [Expanded(child: _ModeCard('BR SQUAD', Icons.groups_outlined)), SizedBox(width: 10), Expanded(child: _ModeCard('CS 4V4', Icons.flash_on_outlined))]),
          const SizedBox(height: 26),
          NfaSectionTitle(
            title: 'Upcoming matches',
            action: TextButton(onPressed: () {}, child: const Text('View all')),
          ),
          const SizedBox(height: 10),
          ...store.matches.where((m) => m.status == MatchStatus.upcoming).take(3).map(
            (m) => Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: _MatchCard(match: m, store: store),
            ),
          ),
        ],
      ),
    );
  }
}

class _WelcomeCard extends StatelessWidget {
  const _WelcomeCard();

  @override
  Widget build(BuildContext context) {
    return NfaGradientCard(
      padding: const EdgeInsets.fromLTRB(20, 20, 18, 20),
      child: Stack(
        children: [
          Positioned(right: -12, top: -18, child: Icon(Icons.bolt_rounded, size: 112, color: Colors.white.withValues(alpha: .07))),
          const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('NFA ARENA', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 12, letterSpacing: 1.5, color: Colors.white70)),
              SizedBox(height: 8),
              Text('Your next match\nstarts here.', style: TextStyle(fontSize: 27, height: 1.05, fontWeight: FontWeight.w900)),
              SizedBox(height: 10),
              Text('Compete. Win. Climb the leaderboard.', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w600)),
            ],
          ),
        ],
      ),
    );
  }
}

class _ModeCard extends StatelessWidget {
  const _ModeCard(this.title, this.icon);
  final String title;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 17, horizontal: 10),
        child: Row(
          children: [
            NfaGlowIcon(icon: icon, size: 42),
            const SizedBox(width: 10),
            Expanded(child: Text(title, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w900))),
          ],
        ),
      ),
    );
  }
}

class _MatchCard extends StatelessWidget {
  const _MatchCard({required this.match, required this.store});
  final TournamentMatch match;
  final MatchStore store;

  @override
  Widget build(BuildContext context) {
    final progress = match.totalSlots == 0 ? 0.0 : (match.totalSlots - match.availableSlots) / match.totalSlots;
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => MatchDetailsScreen(match: match, store: store))),
        child: Padding(
          padding: const EdgeInsets.all(15),
          child: Row(
            children: [
              const NfaGlowIcon(icon: Icons.sports_esports_rounded, size: 48),
              const SizedBox(width: 13),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(match.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900)),
                    const SizedBox(height: 5),
                    Text('${match.mode} • ${match.availableSlots}/${match.totalSlots} slots left', style: const TextStyle(color: AppColors.textSecondary, fontSize: 12, fontWeight: FontWeight.w600)),
                    const SizedBox(height: 9),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(99),
                      child: LinearProgressIndicator(value: progress.clamp(0, 1), minHeight: 5, backgroundColor: AppColors.surface2, valueColor: const AlwaysStoppedAnimation(AppColors.neonBlue)),
                    ),
                    const SizedBox(height: 8),
                    Text('Prize ৳${match.prize}  •  Entry ৳${match.entryFee}', style: const TextStyle(color: AppColors.success, fontWeight: FontWeight.w800, fontSize: 11)),
                  ],
                ),
              ),
              const SizedBox(width: 6),
              const Icon(Icons.chevron_right_rounded, color: AppColors.textSecondary),
            ],
          ),
        ),
      ),
    );
  }
}

class _MatchesTab extends StatefulWidget {
  const _MatchesTab({required this.store});
  final MatchStore store;

  @override
  State<_MatchesTab> createState() => _MatchesTabState();
}

class _MatchesTabState extends State<_MatchesTab> {
  MatchStatus filter = MatchStatus.upcoming;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: widget.store,
      builder: (_, __) {
        final list = widget.store.matches.where((m) => m.status == filter).toList();
        return ListView(
          padding: const EdgeInsets.fromLTRB(18, 12, 18, 30),
          children: [
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(children: [
                _Filter('Upcoming', MatchStatus.upcoming), const SizedBox(width: 8),
                _Filter('Live', MatchStatus.live), const SizedBox(width: 8),
                _Filter('Completed', MatchStatus.completed),
              ]),
            ),
            const SizedBox(height: 16),
            if (list.isEmpty)
              const Card(child: Padding(padding: EdgeInsets.all(32), child: Center(child: Text('No matches in this section.', style: TextStyle(color: AppColors.textSecondary)))))
            else
              ...list.map((m) => Padding(padding: const EdgeInsets.only(bottom: 10), child: _MatchCard(match: m, store: widget.store))),
          ],
        );
      },
    );
  }

  Widget _Filter(String label, MatchStatus value) => ChoiceChip(
        label: Text(label),
        selected: filter == value,
        onSelected: (_) => setState(() => filter = value),
      );
}

class _LeaderboardTab extends StatelessWidget {
  const _LeaderboardTab();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(32),
        child: Text('Leaderboard data will appear here once connected to the results backend.', textAlign: TextAlign.center, style: TextStyle(color: AppColors.textSecondary)),
      ),
    );
  }
}

class _ProfileTab extends StatelessWidget {
  const _ProfileTab();

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 12, 18, 30),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Row(
              children: [
                const CircleAvatar(radius: 30, backgroundColor: AppColors.primary, child: Icon(Icons.person, color: Colors.white, size: 30)),
                const SizedBox(width: 14),
                const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Demo Player', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)), SizedBox(height: 4), Text('NFA-000001', style: TextStyle(color: AppColors.textSecondary, fontSize: 12))])),
                IconButton(onPressed: () {}, icon: const Icon(Icons.edit_outlined)),
              ],
            ),
          ),
        ),
        const SizedBox(height: 14),
        Card(
          child: Column(
            children: [
              const ListTile(leading: Icon(Icons.account_balance_wallet_outlined), title: Text('Wallet'), subtitle: Text('Manage balance and transactions')),
              const Divider(),
              const ListTile(leading: Icon(Icons.rule_outlined), title: Text('Tournament rules')),
              const Divider(),
              ListTile(leading: const Icon(Icons.bug_report_outlined), title: const Text('Report a bug'), subtitle: const Text('Tell us about an app problem'), trailing: const Icon(Icons.chevron_right_rounded), onTap: () => Navigator.pushNamed(context, BugReportScreen.routeName)),
              const Divider(),
              const ListTile(leading: Icon(Icons.settings_outlined), title: Text('Settings')),
            ],
          ),
        ),
      ],
    );
  }
}
