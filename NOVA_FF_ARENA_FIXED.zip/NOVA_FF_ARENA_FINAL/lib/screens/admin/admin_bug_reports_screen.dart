
import 'package:flutter/material.dart';
import '../../core/backend/backend.dart';
import '../../models/bug_report.dart';
import '../../repositories/admin_bug_report_repository.dart';

class AdminBugReportsScreen extends StatefulWidget {
  const AdminBugReportsScreen({super.key});
  static const routeName = '/admin/bug-reports';

  @override
  State<AdminBugReportsScreen> createState() => _AdminBugReportsScreenState();
}

class _AdminBugReportsScreenState extends State<AdminBugReportsScreen> {
  late Future<List<BugReport>> _future;

  @override
  void initState() {
    super.initState();
    _future = AdminBugReportRepository(Backend.client).listOpen();
  }

  void _reload() => setState(() {
    _future = AdminBugReportRepository(Backend.client).listOpen();
  });

  Future<void> _change(BugReport report) async {
    final status = await showModalBottomSheet<BugReportStatus>(
      context: context,
      showDragHandle: true,
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: BugReportStatus.values.map((s) => ListTile(
            title: Text(s.name.toUpperCase()),
            onTap: () => Navigator.pop(context, s),
          )).toList(),
        ),
      ),
    );
    if (status == null || !mounted) return;
    try {
      await AdminBugReportRepository(Backend.client).updateStatus(
        id: report.id,
        status: status,
      );
      _reload();
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not update bug report.')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('BUG REPORTS'),
      actions: [IconButton(onPressed: _reload, icon: const Icon(Icons.refresh))],
    ),
    body: FutureBuilder<List<BugReport>>(
      future: _future,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError) {
          return Center(child: Text('Unable to load reports.'));
        }
        final reports = snapshot.data ?? const <BugReport>[];
        if (reports.isEmpty) {
          return const Center(child: Text('No bug reports found.'));
        }
        return RefreshIndicator(
          onRefresh: () async => _reload(),
          child: ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: reports.length,
            itemBuilder: (_, i) {
              final r = reports[i];
              return Card(
                child: ListTile(
                  title: Text(r.title),
                  subtitle: Text(
                    '${r.severity.toUpperCase()} • ${r.status.name}\n${r.description}',
                    maxLines: 4,
                    overflow: TextOverflow.ellipsis,
                  ),
                  isThreeLine: true,
                  trailing: const Icon(Icons.edit_outlined),
                  onTap: () => _change(r),
                ),
              );
            },
          ),
        );
      },
    ),
  );
}
