import 'package:flutter/material.dart';

import '../../core/backend/backend.dart';
import '../../repositories/bug_report_repository.dart';

class BugReportScreen extends StatefulWidget {
  const BugReportScreen({super.key});

  static const routeName = '/support/bug-report';

  @override
  State<BugReportScreen> createState() => _BugReportScreenState();
}

class _BugReportScreenState extends State<BugReportScreen> {
  final _formKey = GlobalKey<FormState>();
  final _title = TextEditingController();
  final _description = TextEditingController();
  String _severity = 'medium';
  bool _submitting = false;

  @override
  void dispose() {
    _title.dispose();
    _description.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate() || _submitting) return;
    setState(() => _submitting = true);

    try {
      await BugReportRepository(Backend.client).create(
        title: _title.text,
        description: _description.text,
        severity: _severity,
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Bug report submitted. Thank you!')),
      );
      Navigator.pop(context);
    } on AuthException catch (error) {
      _showError(error.message);
    } on PostgrestException catch (_) {
      _showError('Could not submit the report. Please try again.');
    } catch (_) {
      _showError('Network error. Check your connection and try again.');
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  void _showError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('REPORT A BUG')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const Text(
              'Help us improve NFA',
              style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 8),
            const Text(
              'Describe what happened and where it happened. Do not include passwords, OTPs, PINs, or payment secrets.',
            ),
            const SizedBox(height: 24),
            TextFormField(
              controller: _title,
              maxLength: 100,
              decoration: const InputDecoration(
                labelText: 'Bug title',
                hintText: 'Example: Slot selection freezes',
              ),
              validator: (value) {
                if (value == null || value.trim().length < 4) {
                  return 'Enter a short bug title';
                }
                return null;
              },
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: _severity,
              decoration: const InputDecoration(labelText: 'Severity'),
              items: const [
                DropdownMenuItem(value: 'low', child: Text('Low')),
                DropdownMenuItem(value: 'medium', child: Text('Medium')),
                DropdownMenuItem(value: 'high', child: Text('High')),
                DropdownMenuItem(value: 'critical', child: Text('Critical')),
              ],
              onChanged: _submitting
                  ? null
                  : (value) => setState(() => _severity = value ?? 'medium'),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _description,
              minLines: 6,
              maxLines: 10,
              maxLength: 3000,
              decoration: const InputDecoration(
                labelText: 'What went wrong?',
                hintText: 'Steps to reproduce, expected result, and actual result',
                alignLabelWithHint: true,
              ),
              validator: (value) {
                if (value == null || value.trim().length < 10) {
                  return 'Please provide more detail';
                }
                return null;
              },
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: _submitting ? null : _submit,
              icon: _submitting
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.bug_report_outlined),
              label: Text(_submitting ? 'SUBMITTING...' : 'SUBMIT REPORT'),
            ),
          ],
        ),
      ),
    );
  }
}
