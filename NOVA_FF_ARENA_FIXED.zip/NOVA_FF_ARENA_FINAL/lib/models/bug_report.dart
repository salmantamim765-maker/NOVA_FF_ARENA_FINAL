enum BugReportStatus { open, inProgress, resolved, closed }

class BugReport {
  final String id;
  final String userId;
  final String title;
  final String description;
  final String severity;
  final BugReportStatus status;
  final DateTime createdAt;

  const BugReport({
    required this.id,
    required this.userId,
    required this.title,
    required this.description,
    required this.severity,
    required this.status,
    required this.createdAt,
  });

  factory BugReport.fromMap(Map<String, dynamic> map) {
    return BugReport(
      id: map['id'] as String,
      userId: map['user_id'] as String,
      title: map['title'] as String,
      description: map['description'] as String,
      severity: map['severity'] as String,
      status: BugReportStatus.values.firstWhere(
        (value) => value.name == map['status'],
        orElse: () => BugReportStatus.open,
      ),
      createdAt: DateTime.parse(map['created_at'] as String),
    );
  }
}
