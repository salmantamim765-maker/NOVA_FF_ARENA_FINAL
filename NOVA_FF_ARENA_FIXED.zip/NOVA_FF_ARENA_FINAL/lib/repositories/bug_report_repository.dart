import 'package:supabase_flutter/supabase_flutter.dart';

class BugReportRepository {
  BugReportRepository(this.client);

  final SupabaseClient client;

  Future<void> create({
    required String title,
    required String description,
    required String severity,
  }) async {
    final userId = client.auth.currentUser?.id;
    if (userId == null) {
      throw const AuthException('You must be signed in to report a bug.');
    }

    await client.from('bug_reports').insert({
      'user_id': userId,
      'title': title.trim(),
      'description': description.trim(),
      'severity': severity,
    });
  }

  Future<List<Map<String, dynamic>>> mine() async {
    final rows = await client
        .from('bug_reports')
        .select()
        .eq('user_id', client.auth.currentUser!.id)
        .order('created_at', ascending: false);
    return List<Map<String, dynamic>>.from(rows);
  }
}
