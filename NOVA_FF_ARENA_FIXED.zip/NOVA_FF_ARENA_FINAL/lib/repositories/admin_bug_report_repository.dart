
import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/bug_report.dart';

class AdminBugReportRepository {
  AdminBugReportRepository(this.client);
  final SupabaseClient client;

  Future<List<BugReport>> listOpen() async {
    final rows = await client.rpc('admin_list_bug_reports');
    return (rows as List)
        .map((row) => BugReport.fromMap(Map<String, dynamic>.from(row)))
        .toList();
  }

  Future<void> updateStatus({
    required String id,
    required BugReportStatus status,
  }) async {
    await client.rpc('admin_update_bug_report_status', params: {
      'p_id': id,
      'p_status': status.name == 'inProgress' ? 'in_progress' : status.name,
    });
  }
}
