import 'package:flutter/material.dart';

import 'core/theme/app_theme.dart';
import 'screens/auth/login_screen.dart';
import 'screens/home/home_shell.dart';
import 'core/backend/backend.dart';
import 'screens/support/bug_report_screen.dart';
import 'screens/wallet/sandbox_deposit_screen.dart';
import 'screens/admin/admin_bug_reports_screen.dart';
import 'screens/results/results_screen.dart';
import 'screens/leaderboard/leaderboard_screen.dart';

class NovaFfArenaApp extends StatelessWidget {
  const NovaFfArenaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'NOVA FF ARENA',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark(),
      initialRoute: LoginScreen.routeName,
      routes: {
        LoginScreen.routeName: (_) => const LoginScreen(),
        HomeShell.routeName: (_) => const HomeShell(),
        BugReportScreen.routeName: (_) => const BugReportScreen(),
        SandboxDepositScreen.routeName: (_) => const SandboxDepositScreen(),
        AdminBugReportsScreen.routeName: (_) => const AdminBugReportsScreen(),
        '/results': (_) => const ResultsScreen(),
        '/leaderboard': (_) => const LeaderboardScreen(),
      },
    );
  }
}
